package com.vmschmidt.studentapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.vmschmidt.studentapplication.dataprovider.DataProvider;

import java.util.Set;

public class AnalyzeCoursesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_analyze_courses);
    }
}
